package Q2_02_Return_Kth_To_Last;

import CtCILibrary.AssortedMethods;

public class Tester {

	
	public static void main(String[] args) {

	}

}
