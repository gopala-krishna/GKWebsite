package Q7_07_Chat_Server;

public enum RequestStatus {
	Unread, Read, Accepted, Rejected
}
